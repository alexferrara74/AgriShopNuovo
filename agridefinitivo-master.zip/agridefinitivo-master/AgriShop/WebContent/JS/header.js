

document.getElementById("input_ricerca").addEventListener("click", ricerca);


function ricerca(){

document.getElementById("ris__ricerca").style.display="none";
}




