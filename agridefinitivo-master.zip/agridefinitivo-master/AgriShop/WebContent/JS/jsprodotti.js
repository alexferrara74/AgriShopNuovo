/**
 * 
 */

$(document).ready(function(){
$("#risultato").hover(function(){

alert("ciao");
}


);
});


function esegui(){
	
	document.getElementById("prodaction").submit();
	
	
	}
	
	function funzione(){
		
	 document.getElementById("sceltasingolo").submit();
		
	}
